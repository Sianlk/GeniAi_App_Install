# Admin App Initialization
