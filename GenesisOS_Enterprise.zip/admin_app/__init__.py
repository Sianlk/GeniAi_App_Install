# Admin Application Initialization
